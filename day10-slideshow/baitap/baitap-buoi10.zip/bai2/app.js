function onMouseOverEvent() {
	document.getElementById("myImg").src =
		"./images/photo-1653874403269-f4f0dba02f33.avif";
}

function onMouseOutEvent() {
	document.getElementById("myImg").src =
		"./images/photo-1653917207318-a0a2a8a72ff1.avif";
}
